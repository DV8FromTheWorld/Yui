package me.itsghost.jdiscord.message;

public class MessageHistory {

}
