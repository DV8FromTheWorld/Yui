package me.itsghost.jdiscord.talkable;

public interface Talkable {
}
