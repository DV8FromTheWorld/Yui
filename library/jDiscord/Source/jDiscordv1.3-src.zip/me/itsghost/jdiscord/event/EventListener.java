package me.itsghost.jdiscord.event;

public interface EventListener {

}
