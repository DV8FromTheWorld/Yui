package me.itsghost.jdiscord.exception;

public class DiscordFailedToConnectException extends Exception {

}
