package me.itsghost.jdiscord.exception;

public class BadUsernamePasswordException extends Exception {

}
