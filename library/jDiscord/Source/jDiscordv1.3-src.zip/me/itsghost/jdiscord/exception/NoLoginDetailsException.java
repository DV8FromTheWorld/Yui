package me.itsghost.jdiscord.exception;

public class NoLoginDetailsException extends Exception {

}
