package me.itsghost.jdiscord.events;

public class APILoadedEvent {

}
