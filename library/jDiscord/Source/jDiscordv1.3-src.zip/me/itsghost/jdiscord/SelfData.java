package me.itsghost.jdiscord;

import lombok.Data;

@Data
public class SelfData {
    private String username;
    private String email;
    private String id;
    private String avatar;
    private String avatarId;
}
