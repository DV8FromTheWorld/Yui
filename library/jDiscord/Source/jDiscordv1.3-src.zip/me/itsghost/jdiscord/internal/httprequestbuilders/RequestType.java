package me.itsghost.jdiscord.internal.httprequestbuilders;

public enum RequestType {
    POST, GET, PUT, OPTIONS, DELETE, PATCH
}
